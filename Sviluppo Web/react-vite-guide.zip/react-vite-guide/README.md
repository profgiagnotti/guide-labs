# ⚛️ react-vite-guide-Labs — Prof. Giagnotti

![License](https://img.shields.io/badge/license-MIT-blue?style=flat-square)
![Language](https://img.shields.io/badge/lingua-italiano-green?style=flat-square)
![Status](https://img.shields.io/badge/status-attivo-brightgreen?style=flat-square)
![Anno 3](https://img.shields.io/badge/Anno%203-4%20moduli-3DE8A0?style=flat-square)
![Anno 4](https://img.shields.io/badge/Anno%204-3%20moduli-4A9EFF?style=flat-square)
![Anno 5](https://img.shields.io/badge/Anno%205-6%20moduli-BC8CFF?style=flat-square)

Raccolta completa di laboratori tecnici in italiano per lo sviluppo di **Web App con React, Vite e Node JS**.  
Ogni laboratorio è pensato per essere **pratico e completo** — dalla consultazione veloce allo studio approfondito.

> Nuovi laboratori aggiunti ogni settimana. Metti una ⭐ al repo per ricevere notifiche.

---

## 🗂️ Struttura del repository

```
sviluppoWeb-labs/
│
├── Lab01/                      ✅ disponibile   
├── Lab02/                      ✅ disponibile  
├── Lab03/                      ✅ disponibile   
├── Lab04/                      ✅ disponibile  
├── Lab05/                      ✅ disponibile  
├── Lab06/                      ✅ disponibile    
├── Lab07/                      ✅ disponibile   
├── Lab08/                      ✅ disponibile  
├── Lab09/                      ✅ disponibile   
├── Lab10/                      ✅ disponibile  
```

---


### Servizi Web - labs

| Laboratorio | Argomento | Livello |
|---|---|---|
| [Setup ambiente](lab-01-setup-ambiente.md) | Setup dell'ambiente di sviluppo | ⭐ Base |
| [Componenti JSX](lab-02-componenti-jsx.md) | Componenti Vite | ⭐ Base |
| [State hooks](lab-03-state-hooks.md) | State Hooks | ⭐ Base |
| [Styling](lab-04-styling.md) | Stile | ⭐⭐ Intermedio |
| [Routing](lab-05-routing.md) | Routing | ⭐⭐ Intermedio |
| [API Rest](lab-06-api-rest.md) | API Rest | ⭐⭐ Intermedio |
| [Express Backend](lab-07-express-backend.md) | Backend | ⭐⭐ Intermedio |
| [Full stack](lab-08-fullstack.md) | Full stack | ⭐⭐ Intermedio |
| [Autorizzazione con JWT](lab-09-auth-jwt.md) | Autorizzazione JWT | ⭐⭐ Intermedio |
| [Deploy](lab-10-deploy.md) | Deploy | ⭐⭐ Intermedio |
---

## 🤝 Come contribuire

Hai trovato un errore o vuoi aggiungere un laboratorio?

1. Fai un **fork** del repository
2. Crea un branch: `git checkout -b fix/nome-lab`
3. Fai le modifiche e committa: `git commit -m "fix: descrizione modifica"`
4. Apri una **Pull Request**

---

## 🔗 Risorse correlate

- 🌐 **Sito:** [profgiagnotti.it](https://profgiagnotti.it)
- ▶️ **YouTube:** [youtube.com/@profgiagnotti](https://youtube.com/@profgiagnotti)
- 💬 **Discord:** [Unisciti alla community](https://discord.gg/profgiagnotti)
- 📬 **Newsletter:** [profgiagnotti.it/newsletter](https://profgiagnotti.it/newsletter)

---

*Tutti i materiali sono a scopo educativo · Licenza MIT*
