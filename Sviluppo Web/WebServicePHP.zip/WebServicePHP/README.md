# TPS Quinto anno WEB Service API REST PHP

Questo è un semplice repository basato su **PHP**.


## Tecnologie:
- **Apache**
- **PHP**
- **XAMPP**
- **MySQL**
- **phpMyAdmin**

## Come testare i contenuti:

1. Clona il repository:

git clone https://github.com/MarioGiagnotti/TPS-Quinto-anno-WEB-Service-API-REST-PHP.git

oppure fare il Download del file .zip


2. Visualizzazione dell'output

     - Avviare XAMPP
     - Far partire Apache
     - Far partire MySQL
     - Creare o importare il DB
     - Seguire le indicazioni della guida: https://profgiagnotti.it/guida-alla-creazione-e-al-test-di-api-rest-con-php/

     

