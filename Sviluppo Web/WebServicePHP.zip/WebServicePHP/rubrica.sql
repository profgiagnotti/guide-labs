-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Apr 08, 2025 alle 19:52
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rubrica`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `via` varchar(100) DEFAULT NULL,
  `citta` varchar(50) DEFAULT NULL,
  `provincia` varchar(2) DEFAULT NULL,
  `cap` varchar(10) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `cognome`, `nome`, `email`, `via`, `citta`, `provincia`, `cap`, `telefono`, `created_at`) VALUES
(1, 'Rossi', 'Mario', 'mario.rossi@example.com', 'Via Roma 12', 'Milano', 'MI', '20121', '3201234567', '2025-04-08 08:34:57'),
(2, 'Verdi', 'Luca', 'luca.verdi@example.com', 'Via Torino 45', 'Torino', 'TO', '10121', '3339876543', '2025-04-08 08:34:57'),
(3, 'Bianchi', 'Giulia', 'giulia.bianchi@example.com', 'Viale Italia 8', 'Firenze', 'FI', '50100', '3471112233', '2025-04-08 08:34:57'),
(4, 'Russo', 'Anna', 'anna.russo@example.com', 'Corso Venezia 5', 'Napoli', 'NA', '80100', '3894455667', '2025-04-08 08:34:57'),
(5, 'Gallo', 'Stefano', 'stefano.gallo@example.com', 'Via Garibaldi 22', 'Genova', 'GE', '16100', '3925544332', '2025-04-08 08:34:57'),
(6, 'Ferrari', 'Elena', 'elena.ferrari@example.com', 'Via Dante 14', 'Bologna', 'BO', '40121', '3406677889', '2025-04-08 08:34:57'),
(7, 'Marino', 'Francesca', 'francesca.marino@example.com', 'Via Mazzini 3', 'Roma', 'RM', '00100', '3289988776', '2025-04-08 08:34:57'),
(8, 'Conti', 'Paolo', 'paolo.conti@example.com', 'Via Manzoni 9', 'Palermo', 'PA', '90100', '3367766554', '2025-04-08 08:34:57'),
(9, 'De Luca', 'Alessandro', 'alessandro.deluca@example.com', 'Via Foscolo 1', 'Bari', 'BA', '70121', '3481122334', '2025-04-08 08:34:57'),
(10, 'Ricci', 'Laura', 'laura.ricci@example.com', 'Via Verdi 18', 'Venezia', 'VE', '30100', '3514433221', '2025-04-08 08:34:57');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
