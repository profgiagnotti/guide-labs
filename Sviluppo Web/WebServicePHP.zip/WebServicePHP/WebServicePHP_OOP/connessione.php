<?php
class Database {
    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "rubrica";
    private $conn;

    // Connessione al database
    public function getConnection() {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->database);

        if ($this->conn->connect_error) {
            die(json_encode(["message" => "Connessione fallita: " . $this->conn->connect_error]));
        }

        return $this->conn;
    }
}
?>
