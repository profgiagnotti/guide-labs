<?php
// Accesso da qualsiasi dominio
header("Access-Control-Allow-Origin: *");
// Risposta in formato JSON
header("Content-Type: application/json; charset=UTF-8");
// Permette metodi PUT, GET, POST, DELETE
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
// Tempo di caching per le preflight request
header("Access-Control-Max-Age: 3600");
// Header consentiti
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
?>
