<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "rubrica";

// Connessione in stile OOP
$conn = new mysqli($servername, $username, $password, $database);

// Verifica della connessione
if ($conn->connect_error) {
    die(json_encode(["message" => "Connessione fallita: " . $conn->connect_error]));
}
?>
